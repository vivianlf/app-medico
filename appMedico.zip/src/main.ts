import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Criar primeiro usuário (médico)
  const usuarioMedico = await prisma.usuario.create({
    data: {
      nomeCompleto: "Dr. Rafael Lima",
      cpf: "333.664.887-00",
      email: "rafaelima@hospital.com",
      senha: "senhaSegura2035",
      whatsapp: "+5511986543210",
      administrador: true,
    },
  });

  console.log("Usuário Médico criado:", usuarioMedico);

  // Criar médico associado ao usuário
  const medico = await prisma.medico.create({
    data: {
      crm: "988684",
      usuarioId: usuarioMedico.id,
    },
  });

  console.log("Médico criado:", medico);

  // Criar segundo usuário (paciente)
  const usuarioPaciente = await prisma.usuario.create({
    data: {
      nomeCompleto: "Maria Clara",
      cpf: "466.779.133-33",
      email: "marialara@paciente.com",
      senha: "senhaForte2045",
      whatsapp: "+5511997654321",
      administrador: false,
    },
  });

  console.log("Usuário Paciente criado:", usuarioPaciente);

  // Criar paciente associado ao usuário
  const paciente = await prisma.paciente.create({
    data: {
      usuarioId: usuarioPaciente.id,
      dataNascimento: new Date("1987-11-10"),
      sexo: false, // False para feminino, true para masculino
      endereco: "Avenida das Flores, 456",
      objetivo: "EMAGRECIMENTO", // Usando enum
    },
  });

  console.log("Paciente criado:", paciente);

  // Criar exame físico para o paciente
  const exameFisico = await prisma.exameFisico.create({
    data: {
      pacienteId: paciente.id,
      inspecaoGeral: "Paciente apresenta leve cansaço",
      ar: "Respiração normal com leve ruído",
      acv: "Sem sopros detectados",
    },
  });

  console.log("Exame Físico criado:", exameFisico);

  
  // Criar hábitos alimentares para o paciente
  const habitosAlimentares = await prisma.habitosAlimentares.create({
    data: {
      pacienteId: paciente.id,
      compulsaoAlimentar: true,
      gostaDocesAlcool: false,
      fomeNoturna: true,
      fomeEmocional: true,
      habitoBeliscador: true,
    },
  });

  console.log("Hábitos Alimentares criados:", habitosAlimentares);
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
